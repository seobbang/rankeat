import react from "react";
import "../css/CancelProduct.css";


const CancelProduct =()=>{

  return (
    <div className = "Cancelproduct-container">
      <div className = "Cancelproduct">
        <div className = "Cancelproduct_img"><img src="..." alt="..." /></div>
        <div cassName = "Cancelproduct_name">Productname</div>
        <div id = "Cancelbtn"><button>장바구니 취소하기</button></div>
      </div>
      <div className = "Cancelproduct">
        <div className = "Cancelproduct_img"><img src="..." alt="..." /></div>
        <div cassName = "Cancelproduct_name">Productname</div>
        <div id = "Cancelbtn"><button>장바구니 취소하기</button></div>
      </div>
      <div className = "Cancelproduct">
        <div className = "Cancelproduct_img"><img src="..." alt="..." /></div>
        <div cassName = "Cancelproduct_name">Productname</div>
        <div id = "Cancelbtn"><button>장바구니 취소하기</button></div>
      </div>
      
      
      
    </div>
  )
}

export default CancelProduct;