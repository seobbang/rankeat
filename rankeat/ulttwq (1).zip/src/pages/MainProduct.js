import react from "react";
import reactDOM from "react-dom";

const MainProduct =()=>{

  return(
    <div className = "MainProduct-container">
      <div className = "MainProduct"></div>
    </div>
  )
}