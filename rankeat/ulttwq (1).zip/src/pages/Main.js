import react from "react";
import Product from "./Product";


const Main=()=>{

  return (
    <div className = "Main-container">
      
    </div>
  )

}

export default Main;